<?php

namespace Database\Factories;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

/**
 * @extends Factory<User>
 */
class UserFactory extends Factory
{
    /**
     * The current password being used by the factory.
     */
    protected static ?string $password;

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'name' => fake()->name(),
            'email' => fake()->unique()->safeEmail(),
            'email_verified_at' => now(),
            'is_admin' => false,
            'role' => 'operator',
            'must_rotate_password' => false,
            'bootstrap_password_issued_at' => null,
            'password' => static::$password ??= Hash::make('password'),
            'password_rotated_at' => now(),
            'remember_token' => Str::random(10),
        ];
    }

    /**
     * Indicate that the model's email address should be unverified.
     */
    public function unverified(): static
    {
        return $this->state(fn (array $attributes) => [
            'email_verified_at' => null,
        ]);
    }

    public function admin(): static
    {
        return $this->state(fn () => [
            'is_admin' => true,
            'role' => 'license_admin',
        ]);
    }

    public function licenseAdmin(): static
    {
        return $this->state(fn () => [
            'is_admin' => false,
            'role' => 'license_admin',
        ]);
    }

    public function requiresPasswordRotation(): static
    {
        return $this->state(fn () => [
            'must_rotate_password' => true,
            'bootstrap_password_issued_at' => now(),
            'password_rotated_at' => null,
        ]);
    }
}
